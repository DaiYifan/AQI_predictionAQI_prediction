# coding:utf-8

"""
Author: roguesir
Date: 2017/8/30
GitHub: https://roguesir.github.com
Blog: http://blog.csdn.net/roguesir
"""

import numpy as np
from matplotlib import pyplot as plt
from pandas import read_csv
from pandas import DataFrame
from pandas import concat
# dataset = read_csv('new_pollution(1).csv')
dataset = read_csv('data\滨江填补2.csv')
examDf = DataFrame(dataset)
new_examDf = DataFrame(examDf.drop('date',axis=1))
values = new_examDf.values
print(values[200:400,5])
binjiang = values[200:400,5]
x_0 = values[200:400,0]
# l1 = plt.plot(x_0, binjiang, '.-', label='bingjiang',lw=1)

#--------------------
dataset = read_csv('data\朝晖五区填补2.csv')
examDf = DataFrame(dataset)
new_examDf = DataFrame(examDf.drop('date',axis=1))
values = new_examDf.values
chaohui = values[200:400,5].astype('int')
print(chaohui)

#--------------------
dataset = read_csv('data\卧龙桥填补2.csv')
examDf = DataFrame(dataset)
new_examDf = DataFrame(examDf.drop('date',axis=1))
values = new_examDf.values
wolongqiao = values[200:400,5].astype('int')
# print(chaohui)

#--------------------
dataset = read_csv('data\西溪填补2.csv')
examDf = DataFrame(dataset)
new_examDf = DataFrame(examDf.drop('date',axis=1))
values = new_examDf.values
qiandaohu = values[200:400,5].astype('int')
# print(chaohui)

#--------------------
dataset = read_csv('data\和睦小学填补2.csv')
examDf = DataFrame(dataset)
new_examDf = DataFrame(examDf.drop('date',axis=1))
values = new_examDf.values
hemu = values[200:400,5].astype('int')
# print(chaohui)

# x_0 = values[200:400,0]



l1 = plt.plot(x_0, binjiang, '.-', label='bingjiang',lw=1)
l2 = plt.plot(x_0, chaohui, '.-', label='chaohui',lw=1)
l3 = plt.plot(x_0, hemu, '.-', label='hemuxiaoxue',lw=1)
l4 = plt.plot(x_0, qiandaohu, '.-', label='qiandaohu',lw=1)
l5 = plt.plot(x_0, wolongqiao, '.-', label='wolongqiao',lw=1)





plt.ylim(0,250)
plt.xlim(200,400)
plt.legend()
plt.show()
# x1 = [20, 33, 51, 79, 101, 121, 132, 145, 162, 182, 203, 219, 232, 243, 256, 270, 287, 310, 325]
# y1 = [49, 48, 48, 48, 48, 87, 106, 123, 155, 191, 233, 261, 278, 284, 297, 307, 341, 319, 341]
# x2 = [31, 52, 73, 92, 101, 112, 126, 140, 153, 175, 186, 196, 215, 230, 240, 270, 288, 300]
# y2 = [48, 48, 48, 48, 49, 89, 162, 237, 302, 378, 443, 472, 522, 597, 628, 661, 690, 702]
# x3 = [30, 50, 70, 90, 105, 114, 128, 137, 147, 159, 170, 180, 190, 200, 210, 230, 243, 259, 284, 297, 311]
# y3 = [48, 48, 48, 48, 66, 173, 351, 472, 586, 712, 804, 899, 994, 1094, 1198, 1360, 1458, 1578, 1734, 1797, 1892]
#
#
# x_0 = [0,10,20,30,40,50,60,70,80,90,100,150,200]
# LSTM =[16,
#     11.036387859921783,
# 10.462046375718078,
# 10.406626101733888,
# 11.327159103496266,
# 11.400347894571844,
# 11.324042501687996,
# 10.656256306104749,
# 10.254319932131423,
# 10.249885372358287,
# 10.252745842077921,
# 11.191271124894739,
# 12.130012307644416]
# MLP =[18,
#     12.125774555439168,
# 11.567029570970377,
# 10.98421490092697,
# 10.668931680840833,
# 10.675112678594244,
# 11.609660845629202,
# 12.62623140267716,
# 11.680537582754935,
# 11.558234623239578,
# 10.67019054696746,
# 11.860162193253355,
# 12.870064503356405]
# BPNN =[20,
#     14.24127840540017,
# 11.68387546760651,
# 11.455482570579486,
# 12.54174064841464,
# 12.447983279765422,
# 11.326632444776449,
# 11.681141886155595,
# 11.494630439725176,
# 11.081096084159481,
# 11.184581127813919,
# 12.25262008302729,
# 13.767656951178456]
# GRN =[22,
#     21.2544498784898,
# 16.902196357962872,
# 12.646762937327827,
# 11.42536925005052,
# 11.650068919751545,
# 12.319210528015594,
# 12.653291031418714,
# 12.045240846926085,
# 11.818495306568385,
# 12.045812401930984,
# 13.96697247318805,
# 14.04290379755834
# ]
# CNN =[17,
#     14.24127840540017,
# 10.68387546760651,
# 10.455482570579486,
# 10.54174064841464,
# 10.447983279765422,
# 11.326632444776449,
# 11.681141886155595,
# 12.494630439725176,
# 11.781096084159481,
# 11.184581127813919,
# 11.25262008302729,
# 12.767656951178456]
#
# # x = np.arange(20, 350)
# l1 = plt.plot(x_0, LSTM, 'ro-', label='LSTM-STOM',lw=2,color='orange')
# l2 = plt.plot(x_0, MLP, 'g+-', label='MLP',lw=2)
# l3 = plt.plot(x_0, BPNN, 'b^-', label='BPNN',lw=2,color='orchid')
# l3 = plt.plot(x_0, CNN, 'yx-', label='CNN',lw=2,color='blue')
# l3 = plt.plot(x_0, GRN, 'k+-', label='GRN',lw=2,color='red')
# # plt.plot(x1, y1, 'ro-', x2, y2, 'g+-', x3, y3, 'b^-')
# # plt.title('The Lasers in Three Conditions')
# plt.xlabel('epochs')
# plt.ylabel('RMSE')

# plt.legend()
# plt.show()