import matplotlib.pyplot as plt
import numpy as np
from scipy import interpolate

# 设置距离
x = np.array([10, 11, 12, 13, 14, 15, 16, 17, 18, 19,20])

# 设置相似度
y = np.array([153,189,224,225,215,180,210,238,182,175,152])

# 插值法之后的x轴值，表示从0到10间距为0.5的200个数
xnew = np.arange(10, 20, 0.1)

# 实现函数
func = interpolate.interp1d(x, y, kind='cubic')

# 利用xnew和func函数生成ynew,xnew数量等于ynew数量
ynew = func(xnew)

# 原始折线
plt.plot(x, y,'.k')

# 平滑处理后曲线

plt.plot(xnew, ynew,"r",linewidth=1.5)
plt.hlines(180,15,0.5,colors = "k", linestyles = "-.")
plt.vlines(15, 180, 0.5, colors = "k", linestyles = "-.")
plt.hlines(210,16,0.5,colors = "k", linestyles = "-.")
plt.vlines(16, 210, 0.5, colors = "k", linestyles = "-.")
plt.hlines(238,17,0.5,colors = "k", linestyles = "-.")
plt.vlines(17, 238, 0.5, colors = "k", linestyles = "-.")
# 设置x,y轴代表意思
plt.xlabel("Time(h)")
plt.ylabel("AQI")
# 设置标题
# plt.title("The content similarity of different distance")
# 设置x,y轴的坐标范围
plt.xlim(10, 20, 1)
plt.ylim(130, 250,10)
my_x_ticks = np.arange(10, 20, 1)
my_y_ticks = np.arange(130, 250, 10)
plt.xticks(my_x_ticks)
plt.yticks(my_y_ticks)
plt.show()